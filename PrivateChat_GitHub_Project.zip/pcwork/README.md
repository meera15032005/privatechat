# PrivateChat

Android app with a working calculator front screen and an explicitly opened Private Space.

## Included
- Calculator with +, −, ×, ÷, %, decimals, brackets, backspace and clear.
- Private Space protected by a local 4-digit PIN.
- Chat Folder showing saved 1-to-1 chat codes.
- Create a 6-digit chat code or join an existing code.
- Firebase Anonymous Auth and Realtime Database chat.
- Real-time text messages, timestamps, send-error feedback and separate message alignment.
- Included `database.rules.json` for the room structure.

## Firebase
Apply `database.rules.json` to the Realtime Database Rules before testing chat. The Android package is `com.example.privatechat`.

## Scope
This build intentionally does not implement covert microphone/camera/screen recording or privacy bypasses. Media, voice and stronger end-to-end encryption are separate modules and are not falsely presented as completed here.
