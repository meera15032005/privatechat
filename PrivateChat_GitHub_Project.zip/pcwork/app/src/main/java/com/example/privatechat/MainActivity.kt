package com.example.privatechat

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.random.Random

private data class ChatMessage(val id: String = "", val senderUid: String = "", val text: String = "", val time: Long = 0L)
private enum class Screen { CALCULATOR, PRIVATE_HOME, CHAT_FOLDER, CHAT }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrivateChatApp(applicationContext) }
    }
}

@Composable
fun PrivateChatApp(context: Context) {
    var screen by remember { mutableStateOf(Screen.CALCULATOR) }
    var status by remember { mutableStateOf("Connecting…") }
    var uid by remember { mutableStateOf<String?>(null) }
    var roomCode by remember { mutableStateOf<String?>(null) }
    var joinCode by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var pinHash by remember { mutableStateOf(loadPinHash(context)) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pinMode by remember { mutableStateOf("unlock") }
    var chatRooms by remember { mutableStateOf(loadRooms(context)) }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) {
        val auth = FirebaseAuth.getInstance()
        fun ready() { uid = auth.currentUser?.uid; status = if (uid != null) "Connected" else "Not signed in" }
        if (auth.currentUser != null) ready() else auth.signInAnonymously()
            .addOnSuccessListener { ready() }
            .addOnFailureListener { status = "Auth error: ${it.message ?: "unknown error"}" }
    }

    LaunchedEffect(roomCode, uid) {
        val code = roomCode ?: return@LaunchedEffect
        if (uid == null) return@LaunchedEffect
        val ref = FirebaseDatabase.getInstance().reference.child("rooms").child(code).child("messages")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                messages = snapshot.children.mapNotNull { item ->
                    val text = item.child("text").getValue(String::class.java) ?: return@mapNotNull null
                    ChatMessage(item.key.orEmpty(), item.child("senderUid").getValue(String::class.java).orEmpty(), text, item.child("time").getValue(Long::class.java) ?: 0L)
                }.sortedBy { it.time }
            }
            override fun onCancelled(error: DatabaseError) { status = "Chat error: ${error.message}" }
        }
        ref.addValueEventListener(listener)
        awaitDispose { ref.removeEventListener(listener) }
    }

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }

    MaterialTheme {
        when (screen) {
            Screen.CALCULATOR -> CalculatorScreen { pinMode = "unlock"; showPinDialog = true }
            Screen.PRIVATE_HOME -> PrivateHomeScreen(
                status = status, onBack = { screen = Screen.CALCULATOR }, pinSet = pinHash != null,
                onChangePin = { pinMode = "set"; showPinDialog = true },
                onChatFolder = { screen = Screen.CHAT_FOLDER }, onCreate = {
                    val user = uid ?: run { status = "Still connecting…"; return@PrivateHomeScreen }
                    busy = true
                    val code = generateCode()
                    FirebaseDatabase.getInstance().reference.child("rooms").child(code).updateChildren(mapOf(
                        "info/creatorUid" to user, "info/createdAt" to ServerValue.TIMESTAMP, "members/$user" to true
                    )).addOnSuccessListener {
                        roomCode = code; chatRooms = addRoom(context, chatRooms, code); screen = Screen.CHAT; status = "Connected"; busy = false
                    }.addOnFailureListener { status = "Create failed: ${it.message ?: "database error"}"; busy = false }
                }, busy = busy
            )
            Screen.CHAT_FOLDER -> ChatFolderScreen(
                rooms = chatRooms, joinCode = joinCode, onJoinCodeChange = { joinCode = it.filter(Char::isDigit).take(6) }, busy = busy,
                onBack = { screen = Screen.PRIVATE_HOME }, onOpen = { code -> roomCode = code; messages = emptyList(); screen = Screen.CHAT },
                onCreate = {
                    val user = uid ?: run { status = "Still connecting…"; return@ChatFolderScreen }
                    busy = true; val code = generateCode()
                    FirebaseDatabase.getInstance().reference.child("rooms").child(code).updateChildren(mapOf(
                        "info/creatorUid" to user, "info/createdAt" to ServerValue.TIMESTAMP, "members/$user" to true
                    )).addOnSuccessListener {
                        roomCode = code; chatRooms = addRoom(context, chatRooms, code); screen = Screen.CHAT; status = "Connected"; busy = false
                    }.addOnFailureListener { status = "Create failed: ${it.message ?: "database error"}"; busy = false }
                }, onJoin = {
                    val user = uid ?: run { status = "Still connecting…"; return@ChatFolderScreen }
                    val code = joinCode
                    if (code.length != 6) { status = "Enter the 6-digit code"; return@ChatFolderScreen }
                    busy = true
                    val room = FirebaseDatabase.getInstance().reference.child("rooms").child(code)
                    room.child("info").get().addOnSuccessListener { info ->
                        if (!info.exists()) { status = "Chat code not found"; busy = false } else room.child("members").child(user).setValue(true)
                            .addOnSuccessListener { roomCode = code; chatRooms = addRoom(context, chatRooms, code); screen = Screen.CHAT; status = "Connected"; busy = false }
                            .addOnFailureListener { status = "Join failed: ${it.message ?: "database error"}"; busy = false }
                    }.addOnFailureListener { status = "Code check failed: ${it.message ?: "database error"}"; busy = false }
                }
            )
            Screen.CHAT -> ChatScreen(status, roomCode.orEmpty(), uid.orEmpty(), messages, message, { message = it }, listState,
                { screen = Screen.CHAT_FOLDER; roomCode = null; messages = emptyList(); message = "" }, {
                    val code = roomCode ?: return@ChatScreen; val sender = uid ?: return@ChatScreen; val text = message.trim(); if (text.isEmpty()) return@ChatScreen
                    busy = true
                    FirebaseDatabase.getInstance().reference.child("rooms").child(code).child("messages").push().setValue(mapOf("senderUid" to sender, "text" to text, "time" to ServerValue.TIMESTAMP))
                        .addOnSuccessListener { message = ""; status = "Connected"; busy = false }
                        .addOnFailureListener { status = "Send failed: ${it.message ?: "database error"}"; busy = false }
                }, busy)
        }
    }

    if (showPinDialog) PinDialog(pinMode, pinHash, { showPinDialog = false }) { hash ->
        showPinDialog = false
        if (pinMode == "set") { pinHash = hash; savePinHash(context, hash) }
        screen = Screen.PRIVATE_HOME
    }
}

@Composable
private fun CalculatorScreen(onPrivateSpace: () -> Unit) {
    var expression by remember { mutableStateOf("") }
    var display by remember { mutableStateOf("0") }
    fun press(key: String) {
        when (key) {
            "C" -> { expression = ""; display = "0" }
            "⌫" -> { expression = expression.dropLast(1); display = expression.ifEmpty { "0" } }
            "=" -> try { val value = evaluateExpression(expression); display = formatNumber(value); expression = display } catch (_: Exception) { display = "Error"; expression = "" }
            else -> { expression += key; display = expression }
        }
    }
    val rows = listOf(listOf("C", "⌫", "(", ")", "%"), listOf("7", "8", "9", "÷"), listOf("4", "5", "6", "×"), listOf("1", "2", "3", "−"), listOf("0", ".", "=", "+"))
    Scaffold(topBar = { TopAppBar(title = { Text("PrivateChat Calculator") }, actions = { TextButton(onClick = onPrivateSpace) { Text("🔒 Private Space") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.End) {
                Text(expression.ifEmpty { "0" }, style = MaterialTheme.typography.titleMedium)
                Text(display, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Medium)
            } }
            rows.forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) { row.forEach { key ->
                Button(onClick = { press(key) }, modifier = Modifier.weight(1f).height(58.dp), shape = RoundedCornerShape(15.dp)) { Text(key, style = MaterialTheme.typography.titleLarge) }
            } } }
            Text("Supports normal arithmetic, decimals, brackets and percentage calculations.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PrivateHomeScreen(status: String, onBack: () -> Unit, pinSet: Boolean, onChangePin: () -> Unit, onChatFolder: () -> Unit, onCreate: () -> Unit, busy: Boolean) {
    Scaffold(topBar = { TopAppBar(title = { Text("Private Space") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Private Space", style = MaterialTheme.typography.headlineSmall)
            Text("Status: $status")
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), onClick = onChatFolder) { Column(Modifier.padding(18.dp)) { Text("💬 Chat", style = MaterialTheme.typography.titleLarge); Text("Open your private chat folder", style = MaterialTheme.typography.bodyMedium) } }
            Button(onClick = onCreate, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Please wait…" else "Create 1-to-1 Chat") }
            OutlinedButton(onClick = onChangePin, modifier = Modifier.fillMaxWidth()) { Text(if (pinSet) "Change Private Space PIN" else "Set Private Space PIN") }
            Text("Chat data is stored in Firebase according to the included database rules.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ChatFolderScreen(rooms: List<String>, joinCode: String, onJoinCodeChange: (String) -> Unit, busy: Boolean, onBack: () -> Unit, onOpen: (String) -> Unit, onCreate: () -> Unit, onJoin: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Chat Folder") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Your Chats", style = MaterialTheme.typography.headlineSmall)
            if (rooms.isEmpty()) Text("No chats yet. Create a chat or join with a 6-digit code.")
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(rooms, key = { it }) { code ->
                Card(Modifier.fillMaxWidth(), onClick = { onOpen(code) }) { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text("Private Chat", fontWeight = FontWeight.Bold); Text("Code: $code") }; Text("Open ›") } }
            } }
            Button(onClick = onCreate, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("＋ New Chat") }
            OutlinedTextField(value = joinCode, onValueChange = onJoinCodeChange, modifier = Modifier.fillMaxWidth(), label = { Text("6-digit chat code") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            Button(onClick = onJoin, enabled = !busy && joinCode.length == 6, modifier = Modifier.fillMaxWidth()) { Text("Join Chat") }
        }
    }
}

@Composable
private fun ChatScreen(status: String, roomCode: String, uid: String, messages: List<ChatMessage>, message: String, onMessageChange: (String) -> Unit, listState: androidx.compose.foundation.lazy.LazyListState, onBack: () -> Unit, onSend: () -> Unit, busy: Boolean) {
    Scaffold(topBar = { TopAppBar(title = { Column { Text("Private Chat"); Text("Code: $roomCode • $status", style = MaterialTheme.typography.labelSmall) } }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(messages, key = { it.id }) { msg ->
                val mine = msg.senderUid == uid
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) { Card { Column(Modifier.padding(10.dp)) { Text(msg.text); if (msg.time > 0) Text(formatTime(msg.time), style = MaterialTheme.typography.labelSmall) } } }
            } }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(value = message, onValueChange = onMessageChange, modifier = Modifier.weight(1f), placeholder = { Text("Message") }, singleLine = true); Button(onClick = onSend, enabled = !busy && message.isNotBlank()) { Text("Send") } }
        }
    }
}

@Composable
private fun PinDialog(mode: String, existingHash: String?, onDismiss: () -> Unit, onSuccess: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (mode == "set") "Set 4-digit PIN" else "Unlock Private Space") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(4) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true, label = { Text("PIN") }); if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error) } }, confirmButton = { TextButton(onClick = { if (pin.length != 4) error = "Enter exactly 4 digits" else { val hash = sha256(pin); if (mode == "set" || existingHash == null || hash == existingHash) onSuccess(hash) else error = "Wrong PIN" } }) { Text(if (mode == "set") "Save" else "Unlock") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

private class Parser(private val s: String) {
    private var i = 0
    fun parse(): Double { val v = expression(); skip(); if (i != s.length) throw IllegalArgumentException(); return v }
    private fun expression(): Double { var v = term(); while (true) { skip(); if (eat('+')) v += term() else if (eat('−') || eat('-')) v -= term() else return v } }
    private fun term(): Double { var v = factor(); while (true) { skip(); if (eat('×') || eat('*')) v *= factor() else if (eat('÷') || eat('/')) { val d = factor(); if (d == 0.0) throw ArithmeticException(); v /= d } else return v } }
    private fun factor(): Double { skip(); if (eat('+')) return factor(); if (eat('−') || eat('-')) return -factor(); var v = if (eat('(')) { val x = expression(); if (!eat(')')) throw IllegalArgumentException(); x } else number(); skip(); while (eat('%')) v /= 100.0; return v }
    private fun number(): Double { skip(); val start = i; var dot = false; while (i < s.length && (s[i].isDigit() || (s[i] == '.' && !dot))) { if (s[i] == '.') dot = true; i++ }; if (start == i) throw IllegalArgumentException(); return s.substring(start, i).toDouble() }
    private fun skip() { while (i < s.length && s[i].isWhitespace()) i++ }
    private fun eat(c: Char): Boolean { skip(); if (i < s.length && s[i] == c) { i++; return true }; return false }
}

private fun evaluateExpression(s: String): Double { if (s.isBlank()) throw IllegalArgumentException(); val v = Parser(s).parse(); if (!v.isFinite() || abs(v) > 1e100) throw ArithmeticException(); return v }
private fun generateCode(): String = Random.nextInt(100000, 1000000).toString()
private fun formatNumber(v: Double): String { if (!v.isFinite()) return "Error"; val r = kotlin.math.round(v * 1_000_000_000.0) / 1_000_000_000.0; return if (r % 1.0 == 0.0) r.toLong().toString() else r.toString() }
private fun formatTime(time: Long): String = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(time))
private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
private fun loadPinHash(c: Context): String? = c.getSharedPreferences("privatechat", Context.MODE_PRIVATE).getString("pin_hash", null)
private fun savePinHash(c: Context, h: String) { c.getSharedPreferences("privatechat", Context.MODE_PRIVATE).edit().putString("pin_hash", h).apply() }
private fun loadRooms(c: Context): List<String> = c.getSharedPreferences("privatechat", Context.MODE_PRIVATE).getStringSet("rooms", emptySet()).orEmpty().toList().sorted()
private fun addRoom(c: Context, current: List<String>, code: String): List<String> { val set = current.toMutableSet(); set.add(code); c.getSharedPreferences("privatechat", Context.MODE_PRIVATE).edit().putStringSet("rooms", set).apply(); return set.toList().sorted() }
