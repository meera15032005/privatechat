# PrivateChat
Transparent 1-to-1 Android chat starter using Firebase Authentication and Realtime Database.

Before building:
1. Register Android package `com.example.privatechat` in Firebase.
2. Put Firebase's `google-services.json` in `app/google-services.json`.
3. Enable Anonymous Authentication.
4. Configure Realtime Database rules for the two users.

This starter currently implements realtime text chat. Photo/video sharing needs a media-storage backend. Firebase Storage is asking this project for a billing account, so it is not silently enabled.
