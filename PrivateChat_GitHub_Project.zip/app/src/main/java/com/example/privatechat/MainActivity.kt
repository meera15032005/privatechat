package com.example.privatechat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

private const val DB_URL = "https://privatechat-default-rtdb.firebaseio.com"

data class ChatMessage(val id:String="", val senderUid:String="", val text:String="", val time:Long=0L)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrivateChatApp() }
    }
}

@Composable
fun PrivateChatApp() {
    var status by remember { mutableStateOf("Connecting…") }
    var uid by remember { mutableStateOf<String?>(null) }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) {
        val auth = FirebaseAuth.getInstance()
        val ready = {
            uid = auth.currentUser?.uid
            status = if (uid != null) "Connected" else "Not signed in"
        }
        if (auth.currentUser != null) ready()
        else auth.signInAnonymously()
            .addOnSuccessListener { ready() }
            .addOnFailureListener { status = "Auth error: ${it.message}" }
    }

    LaunchedEffect(uid) {
        if (uid == null) return@LaunchedEffect
        FirebaseDatabase.getInstance(DB_URL).reference.child("chat/messages")
            .limitToLast(200)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    messages = s.children.mapNotNull { x ->
                        val text = x.child("text").getValue(String::class.java) ?: return@mapNotNull null
                        ChatMessage(
                            x.key ?: "",
                            x.child("senderUid").getValue(String::class.java) ?: "",
                            text,
                            x.child("time").getValue(Long::class.java) ?: 0L
                        )
                    }.sortedBy { it.time }
                }
                override fun onCancelled(e: DatabaseError) { status = "Database error: ${e.message}" }
            })
    }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = {
                Column {
                    Text("PrivateChat")
                    Text(status, style = MaterialTheme.typography.labelSmall)
                }
            })
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) { msg ->
                        Card(Modifier.fillMaxWidth()) { Text(msg.text, Modifier.padding(12.dp)) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f), placeholder = { Text("Message") }
                    )
                    Button(onClick = {
                        val text = input.trim()
                        val sender = uid ?: return@Button
                        if (text.isEmpty()) return@Button
                        FirebaseDatabase.getInstance(DB_URL).reference.child("chat/messages").push()
                            .setValue(mapOf("senderUid" to sender, "text" to text, "time" to ServerValue.TIMESTAMP))
                        input = ""
                    }) { Text("Send") }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Photo/video sharing is the next module; this starter keeps media disabled until a storage backend is configured.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
