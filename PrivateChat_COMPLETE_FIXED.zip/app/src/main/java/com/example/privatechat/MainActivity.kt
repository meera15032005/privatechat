package com.example.privatechat

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.round
import kotlin.random.Random

private data class ChatMessage(
    val id: String = "",
    val senderUid: String = "",
    val text: String = "",
    val time: Long = 0L
)

private enum class Screen { CALCULATOR, PRIVATE_HOME, CHAT }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrivateChatApp(applicationContext) }
    }
}

@Composable
fun PrivateChatApp(context: Context) {
    var screen by remember { mutableStateOf(Screen.CALCULATOR) }
    var status by remember { mutableStateOf("Connecting…") }
    var uid by remember { mutableStateOf<String?>(null) }
    var roomCode by remember { mutableStateOf<String?>(null) }
    var joinCode by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var pinHash by remember { mutableStateOf(loadPinHash(context)) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pinMode by remember { mutableStateOf("unlock") }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) {
        val auth = FirebaseAuth.getInstance()
        fun finishAuth() {
            uid = auth.currentUser?.uid
            status = if (uid != null) "Connected" else "Not signed in"
        }
        if (auth.currentUser != null) finishAuth()
        else auth.signInAnonymously()
            .addOnSuccessListener { finishAuth() }
            .addOnFailureListener { status = "Auth error: ${it.message ?: "unknown error"}" }
    }

    LaunchedEffect(roomCode, uid) {
        val code = roomCode ?: return@LaunchedEffect
        if (uid == null) return@LaunchedEffect
        val ref = FirebaseDatabase.getInstance().reference.child("rooms").child(code).child("messages")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                messages = snapshot.children.mapNotNull { item ->
                    val text = item.child("text").getValue(String::class.java) ?: return@mapNotNull null
                    ChatMessage(
                        id = item.key.orEmpty(),
                        senderUid = item.child("senderUid").getValue(String::class.java).orEmpty(),
                        text = text,
                        time = item.child("time").getValue(Long::class.java) ?: 0L
                    )
                }.sortedBy { it.time }
            }
            override fun onCancelled(error: DatabaseError) { status = "Chat error: ${error.message}" }
        }
        ref.addValueEventListener(listener)
        awaitDispose { ref.removeEventListener(listener) }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    MaterialTheme {
        when (screen) {
            Screen.CALCULATOR -> CalculatorScreen(
                onPrivateSpace = {
                    pinMode = "unlock"
                    showPinDialog = true
                }
            )
            Screen.PRIVATE_HOME -> PrivateHomeScreen(
                status = status,
                joinCode = joinCode,
                onJoinCodeChange = { joinCode = it.take(6).filter(Char::isDigit) },
                busy = busy,
                pinSet = pinHash != null,
                onBack = { screen = Screen.CALCULATOR },
                onChangePin = { pinMode = "set"; showPinDialog = true },
                onCreate = {
                    val user = uid ?: run { status = "Still connecting…"; return@PrivateHomeScreen }
                    busy = true
                    val code = generateCode()
                    val room = FirebaseDatabase.getInstance().reference.child("rooms").child(code)
                    val values = mapOf(
                        "info/creatorUid" to user,
                        "info/createdAt" to ServerValue.TIMESTAMP,
                        "members/$user" to true
                    )
                    room.updateChildren(values)
                        .addOnSuccessListener {
                            roomCode = code
                            screen = Screen.CHAT
                            status = "Connected"
                            busy = false
                        }
                        .addOnFailureListener {
                            status = "Create failed: ${it.message ?: "database error"}"
                            busy = false
                        }
                },
                onJoin = {
                    val user = uid ?: run { status = "Still connecting…"; return@PrivateHomeScreen }
                    val code = joinCode.trim()
                    if (code.length != 6) {
                        status = "Enter the 6-digit code"
                        return@PrivateHomeScreen
                    }
                    busy = true
                    val room = FirebaseDatabase.getInstance().reference.child("rooms").child(code)
                    room.child("info").get()
                        .addOnSuccessListener { info ->
                            if (!info.exists()) {
                                status = "Chat code not found"
                                busy = false
                            } else {
                                room.child("members").child(user).setValue(true)
                                    .addOnSuccessListener {
                                        roomCode = code
                                        screen = Screen.CHAT
                                        status = "Connected"
                                        busy = false
                                    }
                                    .addOnFailureListener {
                                        status = "Join failed: ${it.message ?: "database error"}"
                                        busy = false
                                    }
                            }
                        }
                        .addOnFailureListener {
                            status = "Code check failed: ${it.message ?: "database error"}"
                            busy = false
                        }
                }
            )
            Screen.CHAT -> ChatScreen(
                status = status,
                roomCode = roomCode.orEmpty(),
                uid = uid.orEmpty(),
                messages = messages,
                message = message,
                onMessageChange = { message = it },
                listState = listState,
                onBack = {
                    screen = Screen.PRIVATE_HOME
                    roomCode = null
                    messages = emptyList()
                    message = ""
                },
                onSend = {
                    val code = roomCode ?: return@ChatScreen
                    val sender = uid ?: return@ChatScreen
                    val text = message.trim()
                    if (text.isEmpty()) return@ChatScreen
                    val ref = FirebaseDatabase.getInstance().reference
                        .child("rooms").child(code).child("messages").push()
                    busy = true
                    ref.setValue(mapOf("senderUid" to sender, "text" to text, "time" to ServerValue.TIMESTAMP))
                        .addOnSuccessListener {
                            message = ""
                            status = "Connected"
                            busy = false
                        }
                        .addOnFailureListener {
                            status = "Send failed: ${it.message ?: "database error"}"
                            busy = false
                        }
                },
                busy = busy
            )
        }
    }

    if (showPinDialog) {
        PinDialog(
            mode = pinMode,
            existingHash = pinHash,
            onDismiss = { showPinDialog = false },
            onSuccess = { newHash ->
                showPinDialog = false
                if (pinMode == "set") {
                    pinHash = newHash
                    savePinHash(context, newHash)
                    screen = Screen.PRIVATE_HOME
                } else {
                    screen = Screen.PRIVATE_HOME
                }
            }
        )
    }
}

@Composable
private fun CalculatorScreen(onPrivateSpace: () -> Unit) {
    var display by remember { mutableStateOf("0") }
    var stored by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<String?>(null) }
    var newNumber by remember { mutableStateOf(true) }

    fun number(value: String) {
        if (newNumber || display == "0") {
            display = value
            newNumber = false
        } else if (display.length < 16) display += value
    }
    fun decimal() {
        if (newNumber) { display = "0."; newNumber = false }
        else if (!display.contains('.')) display += "."
    }
    fun calculate() {
        val left = stored ?: return
        val right = display.toDoubleOrNull() ?: return
        val result = when (op) {
            "+" -> left + right
            "−" -> left - right
            "×" -> left * right
            "÷" -> if (right == 0.0) Double.NaN else left / right
            else -> right
        }
        display = if (result.isNaN() || result.isInfinite()) "Error" else formatNumber(result)
        stored = null; op = null; newNumber = true
    }
    fun operator(next: String) {
        val value = display.toDoubleOrNull() ?: return
        if (stored != null && op != null && !newNumber) calculate()
        stored = display.toDoubleOrNull()
        op = next
        newNumber = true
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("PrivateChat Calculator") }, actions = {
            TextButton(onClick = onPrivateSpace) { Text("🔒 Private Space") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.CenterEnd) {
                    Text(display, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Medium)
                }
            }
            val rows = listOf(
                listOf("C", "⌫", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "−"),
                listOf("1", "2", "3", "+"),
                listOf("0", ".", "=")
            )
            rows.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { key ->
                        Button(
                            onClick = {
                                when (key) {
                                    "C" -> { display = "0"; stored = null; op = null; newNumber = true }
                                    "⌫" -> { if (!newNumber) { display = if (display.length <= 1) "0" else display.dropLast(1) } }
                                    "%" -> { display = formatNumber((display.toDoubleOrNull() ?: 0.0) / 100.0); newNumber = true }
                                    "." -> decimal()
                                    "=" -> calculate()
                                    "+", "−", "×", "÷" -> operator(key)
                                    else -> number(key)
                                }
                            },
                            modifier = Modifier.weight(if (key == "0") 2f else 1f).height(58.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) { Text(key, style = MaterialTheme.typography.titleLarge) }
                    }
                }
            }
            Text("Calculator is fully usable. Private Space is opened explicitly with the lock button.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PrivateHomeScreen(
    status: String,
    joinCode: String,
    onJoinCodeChange: (String) -> Unit,
    busy: Boolean,
    pinSet: Boolean,
    onBack: () -> Unit,
    onChangePin: () -> Unit,
    onCreate: () -> Unit,
    onJoin: () -> Unit
) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("Private Space") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Private Chat", style = MaterialTheme.typography.headlineSmall)
            Text("Status: $status")
            Button(onClick = onCreate, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Please wait…" else "Create 1-to-1 Chat")
            }
            HorizontalDivider()
            OutlinedTextField(
                value = joinCode,
                onValueChange = onJoinCodeChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("6-digit chat code") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Button(onClick = onJoin, enabled = !busy && joinCode.length == 6, modifier = Modifier.fillMaxWidth()) { Text("Join Chat") }
            OutlinedButton(onClick = onChangePin, modifier = Modifier.fillMaxWidth()) {
                Text(if (pinSet) "Change Private Space PIN" else "Set Private Space PIN")
            }
            Text("The PIN protects entry to this app's Private Space. Chat data uses Firebase rules; stronger end-to-end encryption is a separate module.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ChatScreen(
    status: String,
    roomCode: String,
    uid: String,
    messages: List<ChatMessage>,
    message: String,
    onMessageChange: (String) -> Unit,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onBack: () -> Unit,
    onSend: () -> Unit,
    busy: Boolean
) {
    Scaffold(topBar = {
        TopAppBar(title = { Column { Text("Private Chat"); Text("Code: $roomCode • $status", style = MaterialTheme.typography.labelSmall) } }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.id }) { msg ->
                    val mine = msg.senderUid == uid
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Card { Column(Modifier.padding(10.dp)) {
                            Text(msg.text)
                            if (msg.time > 0) Text(formatTime(msg.time), style = MaterialTheme.typography.labelSmall)
                        } }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = message, onValueChange = onMessageChange, modifier = Modifier.weight(1f), placeholder = { Text("Message") }, singleLine = true)
                Button(onClick = onSend, enabled = !busy && message.isNotBlank()) { Text("Send") }
            }
        }
    }
}

@Composable
private fun PinDialog(
    mode: String,
    existingHash: String?,
    onDismiss: () -> Unit,
    onSuccess: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (mode == "set") "Set 4-digit PIN" else "Unlock Private Space") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(4) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true, label = { Text("PIN") })
                if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (pin.length != 4) { error = "Enter exactly 4 digits"; return@TextButton }
                val hash = sha256(pin)
                if (mode == "set") onSuccess(hash)
                else if (existingHash == null) onSuccess(hash)
                else if (hash == existingHash) onSuccess(hash) else error = "Wrong PIN"
            }) { Text(if (mode == "set") "Save" else "Unlock") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun generateCode(): String = Random.nextInt(100000, 1000000).toString()

private fun formatNumber(value: Double): String {
    val rounded = round(value * 1_000_000_000.0) / 1_000_000_000.0
    return if (rounded % 1.0 == 0.0) rounded.toLong().toString() else rounded.toString()
}

private fun formatTime(time: Long): String = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(time))

private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }

private fun loadPinHash(context: Context): String? = context.getSharedPreferences("privatechat", Context.MODE_PRIVATE).getString("pin_hash", null)

private fun savePinHash(context: Context, hash: String) { context.getSharedPreferences("privatechat", Context.MODE_PRIVATE).edit().putString("pin_hash", hash).apply() }
