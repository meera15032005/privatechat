# PrivateChat

PrivateChat is a transparent calculator + explicitly opened private-space chat app.

## Included in this build
- Fully working calculator: +, −, ×, ÷, %, decimal, backspace, clear and equals.
- Clearly labeled **Private Space** button.
- 4-digit PIN protection for the Private Space (PIN is stored as a SHA-256 hash locally).
- Firebase anonymous sign-in.
- Create a 6-digit 1-to-1 chat code.
- Join a chat with a 6-digit code.
- Real-time text messages.
- Sender/receiver alignment and timestamps.
- Send success/failure handling.
- Firebase Realtime Database rules file: `database.rules.json`.

## Not silently implemented
Camera/microphone recording, covert monitoring, or privacy-bypass behavior is not included.
End-to-end encryption, media transfer, typing/read receipts and message deletion are separate modules and should be added only after the core chat is stable.
