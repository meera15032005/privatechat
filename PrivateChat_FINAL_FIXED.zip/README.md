# PrivateChat

A transparent 1-to-1 Android chat starter using Firebase Anonymous Authentication and Firebase Realtime Database.

## Included in this package
- Android package: `com.example.privatechat`
- Firebase configuration file: `app/google-services.json`
- Anonymous Firebase sign-in
- Realtime text chat
- GitHub Actions workflow that builds a debug APK
- No hidden camera, microphone, screen-capture, or other covert monitoring

## Firebase setup
The included `google-services.json` is configured for the `com.example.privatechat` Android app.

Before the first chat test:
1. In Firebase Console, enable **Authentication → Anonymous**.
2. Create/enable **Realtime Database** for the Firebase project.
3. Set database rules appropriate for your two-user chat. Do not leave a production database publicly readable/writable.

The app uses `FirebaseDatabase.getInstance()` so it uses the default Realtime Database configured for the Firebase project rather than a hard-coded database URL.

## Build
GitHub Actions uses Java 17 and Gradle 8.9 with Android Gradle Plugin 8.7.3.

The workflow artifact is:
`PrivateChat-debug-apk`

## Note about media
This package intentionally keeps photo/video sharing disabled. Adding media requires a storage/backend configuration and explicit user actions/permissions.
