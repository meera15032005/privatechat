package com.example.privatechat

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.security.MessageDigest
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.random.Random

private data class ChatMessage(
    val id: String = "",
    val senderUid: String = "",
    val text: String = "",
    val time: Long = 0L
)

private enum class Screen { CALCULATOR, PRIVATE_HOME, CHAT }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrivateChatApp(applicationContext) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrivateChatApp(context: Context) {
    var screen by remember { mutableStateOf(Screen.CALCULATOR) }
    var status by remember { mutableStateOf("Connecting…") }
    var uid by remember { mutableStateOf<String?>(null) }
    var roomCode by remember { mutableStateOf<String?>(null) }
    var joinCode by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var pinHash by remember { mutableStateOf(loadPinHash(context)) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pinMode by remember { mutableStateOf("unlock") }
    var savedChats by remember { mutableStateOf(loadSavedChats(context)) }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) {
        val auth = FirebaseAuth.getInstance()
        fun finishAuth() {
            uid = auth.currentUser?.uid
            status = if (uid != null) "Connected" else "Not signed in"
        }
        if (auth.currentUser != null) finishAuth()
        else auth.signInAnonymously()
            .addOnSuccessListener { finishAuth() }
            .addOnFailureListener { status = "Auth error: ${it.message ?: "unknown error"}" }
    }

    DisposableEffect(roomCode, uid) {
        val code = roomCode
        val user = uid
        if (code == null || user == null) {
            onDispose { }
        } else {
            val ref = FirebaseDatabase.getInstance().reference
                .child("rooms").child(code).child("messages")
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    messages = snapshot.children.mapNotNull { item ->
                        val text = item.child("text").getValue(String::class.java) ?: return@mapNotNull null
                        ChatMessage(
                            id = item.key.orEmpty(),
                            senderUid = item.child("senderUid").getValue(String::class.java).orEmpty(),
                            text = text,
                            time = item.child("time").getValue(Long::class.java) ?: 0L
                        )
                    }.sortedBy { it.time }
                }
                override fun onCancelled(error: DatabaseError) {
                    status = "Chat error: ${error.message}"
                }
            }
            ref.addValueEventListener(listener)
            onDispose { ref.removeEventListener(listener) }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    MaterialTheme {
        when (screen) {
            Screen.CALCULATOR -> CalculatorScreen(
                onPrivateSpace = {
                    pinMode = if (pinHash == null) "set" else "unlock"
                    showPinDialog = true
                }
            )
            Screen.PRIVATE_HOME -> PrivateHomeScreen(
                status = status,
                joinCode = joinCode,
                onJoinCodeChange = { joinCode = it.filter(Char::isDigit).take(6) },
                busy = busy,
                pinSet = pinHash != null,
                savedChats = savedChats,
                onBack = { screen = Screen.CALCULATOR },
                onOpenChat = { code -> roomCode = code; screen = Screen.CHAT },
                onDeleteChat = { code -> savedChats = removeChatCode(context, code) },
                onChangePin = { pinMode = "set"; showPinDialog = true },
                onCreate = {
                    val user = uid
                    if (user == null) {
                        status = "Still connecting…"
                        return@PrivateHomeScreen
                    }
                    busy = true
                    val code = generateCode()
                    val room = FirebaseDatabase.getInstance().reference.child("rooms").child(code)
                    val values = mapOf(
                        "info/creatorUid" to user,
                        "info/createdAt" to ServerValue.TIMESTAMP,
                        "members/$user" to true
                    )
                    room.updateChildren(values)
                        .addOnSuccessListener {
                            roomCode = code
                            savedChats = saveChatCode(context, code)
                            screen = Screen.CHAT
                            status = "Connected"
                            busy = false
                        }
                        .addOnFailureListener {
                            status = "Create failed: ${it.message ?: "database error"}"
                            busy = false
                        }
                },
                onJoin = {
                    val user = uid
                    if (user == null) {
                        status = "Still connecting…"
                        return@PrivateHomeScreen
                    }
                    val code = joinCode.trim()
                    if (code.length != 6) {
                        status = "Enter the 6-digit code"
                        return@PrivateHomeScreen
                    }
                    busy = true
                    val room = FirebaseDatabase.getInstance().reference.child("rooms").child(code)
                    room.child("info").get()
                        .addOnSuccessListener { info ->
                            if (!info.exists()) {
                                status = "Chat code not found"
                                busy = false
                            } else {
                                room.child("members").child(user).setValue(true)
                                    .addOnSuccessListener {
                                        roomCode = code
                                        savedChats = saveChatCode(context, code)
                                        screen = Screen.CHAT
                                        status = "Connected"
                                        busy = false
                                    }
                                    .addOnFailureListener {
                                        status = "Join failed: ${it.message ?: "database error"}"
                                        busy = false
                                    }
                            }
                        }
                        .addOnFailureListener {
                            status = "Code check failed: ${it.message ?: "database error"}"
                            busy = false
                        }
                }
            )
            Screen.CHAT -> ChatScreen(
                status = status,
                roomCode = roomCode.orEmpty(),
                uid = uid.orEmpty(),
                messages = messages,
                message = message,
                onMessageChange = { message = it },
                listState = listState,
                onBack = {
                    screen = Screen.PRIVATE_HOME
                    roomCode = null
                    messages = emptyList()
                    message = ""
                },
                onSend = {
                    val code = roomCode ?: return@ChatScreen
                    val sender = uid ?: return@ChatScreen
                    val text = message.trim()
                    if (text.isEmpty()) return@ChatScreen
                    val ref = FirebaseDatabase.getInstance().reference
                        .child("rooms").child(code).child("messages").push()
                    busy = true
                    ref.setValue(mapOf("senderUid" to sender, "text" to text, "time" to ServerValue.TIMESTAMP))
                        .addOnSuccessListener {
                            message = ""
                            status = "Connected"
                            busy = false
                        }
                        .addOnFailureListener {
                            status = "Send failed: ${it.message ?: "database error"}"
                            busy = false
                        }
                },
                busy = busy
            )
        }
    }

    if (showPinDialog) {
        PinDialog(
            mode = pinMode,
            existingHash = pinHash,
            onDismiss = { showPinDialog = false },
            onSuccess = { newHash ->
                showPinDialog = false
                if (pinMode == "set") {
                    pinHash = newHash
                    savePinHash(context, newHash)
                }
                screen = Screen.PRIVATE_HOME
            }
        )
    }
}

@Composable
private fun CalculatorScreen(onPrivateSpace: () -> Unit) {
    var expression by remember { mutableStateOf("") }
    var display by remember { mutableStateOf("0") }
    var justEvaluated by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf<List<String>>(emptyList()) }

    fun addToken(token: String) {
        if (justEvaluated && (token.firstOrNull()?.isDigit() == true || token == "." || token == "(")) {
            expression = ""
        }
        justEvaluated = false
        expression = when {
            token == "⌫" -> expression.dropLast(1)
            token == "C" -> ""
            token == "±" -> toggleSign(expression)
            else -> expression + token
        }
        display = expression.ifBlank { "0" }
    }

    fun evaluate() {
        if (expression.isBlank()) return
        try {
            val result = ExpressionParser(expression).parse()
            val formatted = formatNumber(result)
            history = (listOf("$expression = $formatted") + history).take(10)
            display = formatted
            expression = formatted
            justEvaluated = true
        } catch (_: Exception) {
            display = "Error"
            justEvaluated = true
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("PrivateChat Calculator") },
            actions = { TextButton(onClick = onPrivateSpace) { Text("🔒 Private Space") } }
        )
    }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.End) {
                    if (expression.isNotBlank()) Text(expression, style = MaterialTheme.typography.bodySmall)
                    Text(display, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Medium)
                }
            }
            val rows = listOf(
                listOf("C", "⌫", "(", ")", "%"),
                listOf("7", "8", "9", "÷", "±"),
                listOf("4", "5", "6", "×", "+"),
                listOf("1", "2", "3", "−", "."),
                listOf("0", "=")
            )
            rows.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    row.forEach { key ->
                        Button(
                            onClick = { if (key == "=") evaluate() else addToken(key) },
                            modifier = Modifier.weight(if (key == "0") 2f else 1f).height(54.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text(key, style = MaterialTheme.typography.titleMedium) }
                    }
                }
            }
            if (history.isNotEmpty()) {
                Text("History", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                LazyColumn(Modifier.weight(1f, fill = false)) {
                    items(history) { Text(it, modifier = Modifier.padding(vertical = 2.dp)) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrivateHomeScreen(
    status: String,
    joinCode: String,
    onJoinCodeChange: (String) -> Unit,
    busy: Boolean,
    pinSet: Boolean,
    savedChats: List<String>,
    onBack: () -> Unit,
    onOpenChat: (String) -> Unit,
    onDeleteChat: (String) -> Unit,
    onChangePin: () -> Unit,
    onCreate: () -> Unit,
    onJoin: () -> Unit
) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("Private Space") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Private Chat", style = MaterialTheme.typography.headlineSmall)
            Text("Status: $status")
            Button(onClick = onCreate, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Please wait…" else "Create 1-to-1 Chat")
            }
            Text("Chat Folder", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (savedChats.isEmpty()) {
                Text("No saved chats yet.", style = MaterialTheme.typography.bodySmall)
            } else {
                savedChats.forEach { code ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { onOpenChat(code) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Chat $code") }
                        TextButton(onClick = { onDeleteChat(code) }, enabled = !busy) { Text("Delete") }
                    }
                }
            }
            HorizontalDivider()
            OutlinedTextField(
                value = joinCode,
                onValueChange = onJoinCodeChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("6-digit chat code") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Button(onClick = onJoin, enabled = !busy && joinCode.length == 6, modifier = Modifier.fillMaxWidth()) { Text("Join Chat") }
            OutlinedButton(onClick = onChangePin, modifier = Modifier.fillMaxWidth()) {
                Text(if (pinSet) "Change Private Space PIN" else "Set Private Space PIN")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScreen(
    status: String,
    roomCode: String,
    uid: String,
    messages: List<ChatMessage>,
    message: String,
    onMessageChange: (String) -> Unit,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onBack: () -> Unit,
    onSend: () -> Unit,
    busy: Boolean
) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Column { Text("Private Chat"); Text("Code: $roomCode • $status", style = MaterialTheme.typography.labelSmall) } },
            navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
        )
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.id }) { msg ->
                    val mine = msg.senderUid == uid
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Card { Column(Modifier.padding(10.dp)) { Text(msg.text); if (msg.time > 0) Text(formatTime(msg.time), style = MaterialTheme.typography.labelSmall) } }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = message, onValueChange = onMessageChange, modifier = Modifier.weight(1f), placeholder = { Text("Message") }, singleLine = true)
                Button(onClick = onSend, enabled = !busy && message.isNotBlank()) { Text("Send") }
            }
        }
    }
}

@Composable
private fun PinDialog(mode: String, existingHash: String?, onDismiss: () -> Unit, onSuccess: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (mode == "set") "Set 4-digit PIN" else "Unlock Private Space") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(4) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true, label = { Text("PIN") })
                if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (pin.length != 4) { error = "Enter exactly 4 digits"; return@TextButton }
                val hash = sha256(pin)
                if (mode == "set") onSuccess(hash)
                else if (hash == existingHash) onSuccess(hash) else error = "Wrong PIN"
            }) { Text(if (mode == "set") "Save" else "Unlock") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private class ExpressionParser(private val source: String) {
    private var pos = 0
    fun parse(): Double {
        val value = expression()
        skipSpaces()
        if (pos != source.length) error("Unexpected input")
        if (!value.isFinite()) error("Invalid result")
        return value
    }
    private fun expression(): Double {
        var value = term()
        while (true) {
            skipSpaces()
            value = when {
                match('+') -> value + term()
                match('−') || match('-') -> value - term()
                else -> return value
            }
        }
    }
    private fun term(): Double {
        var value = factor()
        while (true) {
            skipSpaces()
            value = when {
                match('×') || match('*') -> value * factor()
                match('÷') || match('/') -> {
                    val divisor = factor()
                    if (divisor == 0.0) error("Division by zero")
                    value / divisor
                }
                else -> return value
            }
        }
    }
    private fun factor(): Double {
        skipSpaces()
        if (match('+')) return factor()
        if (match('−') || match('-')) return -factor()
        var value = if (match('(')) {
            val inside = expression()
            if (!match(')')) error("Missing )")
            inside
        } else number()
        while (true) {
            skipSpaces()
            if (match('%')) value /= 100.0 else return value
        }
    }
    private fun number(): Double {
        skipSpaces()
        val start = pos
        var dots = 0
        while (pos < source.length) {
            val c = source[pos]
            if (c.isDigit()) pos++
            else if (c == '.') { dots++; pos++; if (dots > 1) break }
            else break
        }
        if (start == pos) error("Number expected")
        return source.substring(start, pos).toDoubleOrNull() ?: error("Invalid number")
    }
    private fun match(c: Char): Boolean {
        if (pos < source.length && source[pos] == c) { pos++; return true }
        return false
    }
    private fun skipSpaces() { while (pos < source.length && source[pos].isWhitespace()) pos++ }
}

private fun toggleSign(value: String): String {
    if (value.isBlank()) return "-"
    return if (value.startsWith("-")) value.drop(1) else "-$value"
}

private fun generateCode(): String = Random.nextInt(100000, 1000000).toString()

private fun formatNumber(value: Double): String {
    if (!value.isFinite()) return "Error"
    val normalized = if (abs(value) < 0.0000000005) 0.0 else value
    return try {
        BigDecimal.valueOf(normalized).stripTrailingZeros().toPlainString()
    } catch (_: Exception) {
        "Error"
    }
}

private fun formatTime(time: Long): String = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(time))

private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }

private fun loadPinHash(context: Context): String? = context.getSharedPreferences("privatechat", Context.MODE_PRIVATE).getString("pin_hash", null)
private fun savePinHash(context: Context, hash: String) { context.getSharedPreferences("privatechat", Context.MODE_PRIVATE).edit().putString("pin_hash", hash).apply() }

private fun loadSavedChats(context: Context): List<String> = context.getSharedPreferences("privatechat", Context.MODE_PRIVATE).getStringSet("chat_codes", emptySet())!!.toList().sorted()
private fun saveChatCode(context: Context, code: String): List<String> {
    val prefs = context.getSharedPreferences("privatechat", Context.MODE_PRIVATE)
    val values = (prefs.getStringSet("chat_codes", emptySet()) ?: emptySet()).toMutableSet()
    values.add(code)
    prefs.edit().putStringSet("chat_codes", values).apply()
    return values.toList().sorted()
}
private fun removeChatCode(context: Context, code: String): List<String> {
    val prefs = context.getSharedPreferences("privatechat", Context.MODE_PRIVATE)
    val values = (prefs.getStringSet("chat_codes", emptySet()) ?: emptySet()).toMutableSet()
    values.remove(code)
    prefs.edit().putStringSet("chat_codes", values).apply()
    return values.toList().sorted()
}
