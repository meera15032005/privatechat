# PrivateChat

Android app prototype with a working calculator, explicit PIN-protected Private Space, saved Chat Folder, and Firebase real-time text chat.

## Build versions
- Android Gradle Plugin 8.7.3
- Gradle 8.9 (GitHub Actions)
- Kotlin 2.0.21
- Java 17
- Compile/Target SDK 35
- Compose BOM 2024.12.01
- Firebase Auth 23.1.0
- Firebase Realtime Database 21.0.0

## Main features
- Calculator: +, -, ×, ÷, %, parentheses, decimals, sign toggle, backspace, clear, expression evaluation and history.
- Private Space: explicit 4-digit PIN gate.
- Chat Folder: saves chat codes locally so chats can be reopened.
- Chat: create/join with a 6-digit code and real-time Firebase text messages.

This build does not implement covert recording, hidden surveillance, or bypass Android privacy controls.
